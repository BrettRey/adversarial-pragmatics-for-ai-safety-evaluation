# Code review package: three AI-assurance papers and their executable artifacts

Prepared 2026-07-29 by Brett Reynolds. Everything here comes from a clean clone of
`github.com/BrettRey/adversarial-pragmatics-for-ai-safety-evaluation` at commit `812d407`.

## What I'm asking you to do

The three papers stake claims on this code. None of those claims is a reported
empirical result yet, so this isn't a request to reproduce numbers. It's a request
to find out whether the code does what the papers say it does, before it starts
producing results anyone relies on.

**The single highest-value question: can you make any of these analyzers or
validators emit a false pass?** A tool that reports `supported`, `PASS`, or a
positive verdict on input that should have been refused is the failure that
matters. Everything else is secondary.

Concretely, worth attacking:

- Feed an analyzer a record that should be defeated or unevaluable and see whether
  it returns support.
- Get a verdict out of an input whose manifest hash doesn't match its content.
- Get a reference or oracle field into a reviewer or predictor view (the code is
  supposed to reject leakage).
- Make a claim register validate while containing a post-hoc narrowed claim.
- Make the binding stamper stamp after a genuine response exists, or after the
  freeze boundary has passed.
- Produce a result where a required family is missing, instead of the
  `NOT_ESTIMATED` the design says you should get.

Secondary: places where the code is merely wrong rather than exploitable, and
places where a paper describes behaviour the code doesn't have.

## My concerns, stated plainly

**1. The tests were written alongside the code, largely by the same process.**
They demonstrate internal consistency, not correctness. A misconception shared
between the implementation and its tests passes silently. This is my main worry
and it's why I want an outside reader.

**2. `scripts/analyze_delegation_programs.py` is an 838-line reimplementation
that was produced by dispatching the task to a different model.** It was checked
against its tests and its output schema, but no human has read it line by line.
If you only have time for one file, make it this one.

**3. Two checks in this project failed silently in the last ten days, both by
being structurally blind rather than by breaking.** A cited-source completeness
checker used a case-sensitive regex that couldn't see `\Textcite`, so it reported
"99/99 sources archived" while a cited source had no archive record at all. And
while preparing this package, a search for negative test coverage reported zero
for two suites, because the search terms didn't include the words those tests
actually use ("prohibited", "refuses"). Both passed cleanly while being wrong
about the thing they were checking. Assume more of these exist.

**4. Nothing reported in the papers currently depends on these analyzers.**
Study B's committed record is `NOT_ESTIMATED`, none of the delegation paper's
three empirical programmes has been run, and the evidentiary paper has zero
reviewer responses. So a bug here cannot have corrupted a published number. That
lowers the stakes and is the reason this review is happening now rather than
under deadline. It also means you should not assume any code path has been
exercised on real data, because none has.

**5. The papers make one specific falsifiable claim about this code.** The
evidentiary paper, page 25, says a validator, an analyser with in-memory
self-tests, and a binding stamper are included "so that every hash and
cross-reference in the artifact can be checked from a clean clone with no network
access." I've tested that and it held for me. Please try to break it.

## How to run everything

Python 3 only. No installation, no network access required, no API keys. Run all
of these from this directory. Every one of them passed here on 2026-07-29.

Evidentiary assurance:

```
python3 scripts/validate_evidentiary_artifacts.py
python3 scripts/analyze_evidentiary_calibration.py --self-test
python3 scripts/analyze_evidentiary_calibration.py
python3 scripts/stamp_evidentiary_artifacts.py --check
python3 -m unittest scripts.test_stamp_evidentiary_artifacts
```

Delegation assurance:

```
python3 scripts/validate_delegation_artifacts.py
python3 scripts/analyze_delegation_programs.py --validate-specs
python3 scripts/design_analysis.py --profile smoke
python3 -m unittest scripts.test_analyze_delegation_programs
python3 -m unittest scripts.test_validate_delegation_artifacts
python3 -m unittest scripts.test_design_analysis
```

Adversarial pragmatics, Study B and the shared claim machinery:

```
python3 scripts/validate_study_b.py
python3 scripts/validate_study_b_excellence.py
python3 scripts/validate_claim_register.py --self-test
python3 -m unittest scripts.test_validate_study_b
python3 -m unittest scripts.test_validate_study_b_excellence
python3 -m unittest scripts.test_analyze_study_b
```

`design_analysis.py --profile standard` runs 20,000 simulation replicates and
takes a few minutes; `smoke` runs 2,000.

## What's in here

| Path | What it is |
|---|---|
| `papers/` | The three manuscripts as PDFs. Read the code-and-data availability sections first: delegation p. 34, evidentiary p. 25, adversarial pragmatics at the end. |
| `scripts/` | 18 analyzers, validators, and their test suites. |
| `assurance/delegation/` | Schemas, view policy, claim register, fixtures, hidden oracles, frozen programme specifications. |
| `assurance/evidentiary/` | Schemas, applicability map, claim graph, matched cases including `hidden/` and `invalid/`. |
| `assurance/shared/` | The projective-claim schema and validator fixtures used by all three papers. |
| `benchmark/study-b/` | Pre-collection design, claim register, fixtures, manifests, and the no-data record. |
| `benchmark/items,rubrics,results,coverage/` | The seed benchmark and sanitized pilot summaries the validators cross-check against. |
| `*.tex`, `sections*/` | Manuscript sources. Included because one validator checks claims against the paper text, and because you may want to grep what a given claim says. |

## What's deliberately not here

No private research data. Specifically excluded: all Study A evaluator packages
and responses, the frozen pilot's raw author-label bundle, browser adjudication
exports containing the adjudicator's working notes, and a privatized naturalistic
corpus. None of it is needed to review this code, and none of it is in the public
repository either.

The benchmark payloads you will see are harmless colour tokens and dummy secrets
by design.

## Context you may want

These are three linked papers. Delegation assurance supplies authorization
semantics; evidentiary assurance asks what a record warrants about an
authorization claim; adversarial pragmatics is an empirical benchmark for
language-mediated control. The two assurance papers are about to be posted as
preprints and are targeted at *Minds and Machines* and *Computer Law & Security
Review*. Adversarial pragmatics is on arXiv (2607.01153) and targeted at JAIR.

If something here is wrong, I would much rather hear it now than after the
artifacts are tagged and cited. Findings of the form "this passes when it
shouldn't" are the most useful thing you can send back, followed by "the paper
says X and the code does Y."
